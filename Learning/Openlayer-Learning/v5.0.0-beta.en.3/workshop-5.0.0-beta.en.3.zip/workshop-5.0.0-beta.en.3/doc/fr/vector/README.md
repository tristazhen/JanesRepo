# Les sujets liés aux vecteurs

* [Aparté sur les formats](formats.md)
* [Concepts de styles](style-intro.md)
* [Styles personnalisés](style.md)
