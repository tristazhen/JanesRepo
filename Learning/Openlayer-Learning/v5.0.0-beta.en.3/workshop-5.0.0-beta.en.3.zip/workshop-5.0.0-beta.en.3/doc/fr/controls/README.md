# Les `control` et les `interaction`

 * [Le `control` barre d'échelle `ScaleLine`](scaleline.md)
 * [L'`interaction` de sélection `Select`](select.md)
 * [L'`interaction` de dessin `Draw`](draw.md)
 * [L'`interaction` de modification `Modify`](modify.md)
