# Camadas e Fontes de Dados

* [Fontes WMS](wms.md)
* [Fontes de blocos de dados de imagem (`tiles`)](cached.md)
* [Fornecedores proprietários de blocos de dados de imagem](proprietary.md)
* [Dados vetoriais](vector.md)
* [Fontes de imagens vetoriais](imagevector.md)
