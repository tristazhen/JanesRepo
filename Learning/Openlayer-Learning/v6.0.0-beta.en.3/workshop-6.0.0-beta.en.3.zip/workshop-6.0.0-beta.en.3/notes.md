
TODO

 * AH
   * vector tiles
     * more interactivity, less custom styling

 * TS
   * Update vector editing
   * Make sure raster stuff works

 * Custom heatmap rendering
   * tweets with geolocation and time
   * filter by time of day

additional stuff:
 * dynamic layers using custom renderers and WebGL helpers
